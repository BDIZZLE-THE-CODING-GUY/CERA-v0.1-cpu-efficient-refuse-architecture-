# CERA v0.1

CERA (CPU-Efficient Reuse Architecture) is an experimental CPU-only software renderer.

## Requirements
- Python 3.10+
- Tkinter (usually included with Python on macOS)
- No third-party packages required

## Run on macOS
Open Terminal, go to the folder, then run:

```bash
python3 cera.py
```

If Tkinter is unavailable in your Python installation, try the Python 3 build installed from python.org.

## Controls
- Left / Right: rotate
- Up / Down: move camera closer/farther
- Space: pause/resume animation
- B: toggle baseline full redraw and CERA reuse
- R: reset camera
- Esc: quit

## What this prototype actually demonstrates
- A CPU software rasterizer with triangle filling and a depth buffer.
- A baseline that rerenders the full frame.
- A conservative reuse path that returns the cached image if the scene signature is unchanged.
- Tile counts and frame-time readouts.

## Important limitations
This is an early research prototype, not a production renderer and not faster than RTX in general. In v0.1, any scene change invalidates the whole image; tile-based partial invalidation is not implemented yet. The animation therefore mostly exercises full redraw, while pausing lets you see the exact-frame cache hit. Tkinter image upload overhead is also included in the displayed timing.

## Next experiment
A useful v0.2 would use a static background and independently moving objects, track each object's previous and current screen-space bounding box, invalidate only tiles intersecting those boxes, then redraw affected tiles while preserving valid pixels elsewhere. Correct depth handling and occlusion make this a research challenge.
